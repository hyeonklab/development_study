//
//  ViewController.swift
//  UnitConverter
//
//  Created by mud0107 on 2014. 11. 7..
//  Copyright (c) 2014년 mud0107. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var tempText: UITextField!
    @IBOutlet var resultLabel: UILabel!
    
    
    @IBAction func convertTemp(sender: AnyObject) {
        
        // 여기에 코드를 삽입해세요!!
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

